package Objeto_geometrico_poo;

abstract public class ObjetoGeometrico {
    public double area;
    public double perimetro;
    protected String cor;
    
    public String getCor() {
        return cor;
    }
    
    public void setCor(String c) {
        cor = c;
    }
}
